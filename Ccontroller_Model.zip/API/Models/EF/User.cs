﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using EventIt.Controllers;
using EventIt.Models.EF;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;




#nullable disable

namespace EventIt.Models.EF
{
    public partial class User
    {
        public User()
        {
            Plans = new HashSet<Plan>();
        }
        [JsonIgnore]
        public int UserId { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        
        [JsonIgnore]
        public virtual ICollection<Plan> Plans { get; set; }

        EventItContext db = new EventItContext();

        #region CREATE
        public string createUser(User newUser)
        {
            if (newUser != null)
            {
                var vUser = db.Users;
                foreach (var user in vUser)
                {
                    if ((newUser.Email == user.Email) &&
                        (newUser.Name == user.Name))
                    {
                        throw new Exception("USER ALREADY EXIST IN SYSTEM");
                    }
                }

                var iDparam = new SqlParameter()
                {
                    ParameterName = "@iD",
                    SqlDbType = System.Data.SqlDbType.Int,
                    Direction = System.Data.ParameterDirection.Output
                };

                db.Database.ExecuteSqlRaw("exec addUser " + (newUser.Email) + ", " + 
                                         (newUser.Password) + ", " + (newUser.Name) + 
                                         ", " + "@iD ", iDparam);

           
                // As EF Core cannot get the store procedure out parameter based on what I can 
                // find online, I'm bypassing that and just using another method to look for the
                // value that I want from the DB. - Michael
                int newID = newUser.getUserID(newUser.Email);

                db.SaveChanges();
                return "New User Created with ID#" + newID;

            }
            else
                throw new Exception("INVALID INPUT");
            
        }
        // IMPLEMENTED ^
        #endregion

        #region READ
        public DbSet<User> getUserList ()
        {
            var vUsers = db.Users;

            if (vUsers.Count() == 0)
            {
                throw new Exception("NO USER IN THE SYSTEM!");
            }
            else
            {
                return vUsers;
            }
        }
        // IMPLEMENTED ^
        public User getUser(int? id)
        {
            var vUser = from user in db.Users
                        where user.UserId == id
                        select user;
            int count = 0;
            User foundUser = new User();
            foreach (var u in vUser)
            {
                foundUser.UserId = u.UserId;
                foundUser.Email = u.Email;  
                foundUser.Password = u.Password;
                foundUser.Name = u.Name;
                
                count++;
            }

            if (count == 0)
            {
                throw new Exception("NO USER IN THE SYSTEM!");
            }
            else
            {
                return foundUser;
            }
        }
        // IMPLEMENTED ^
        public int getUserID(string email)
        {
            var vUser = from user in db.Users
                        where user.Email == email
                        select user;
            int count = 0;
            User foundUser = new User();
            foreach (var u in vUser)
            {
                foundUser.UserId = u.UserId;
                foundUser.Email = u.Email;
                foundUser.Password = u.Password;
                foundUser.Name = u.Name;

                count++;
            }

            if (count == 0)
            {
                throw new Exception("NO USER IN THE SYSTEM!");
            }
            else
            {
             

                return foundUser.UserId;
            }
        }
        // IMPLEMENTED ^
        #endregion

        #region UPDATE
        // This method will update user name and email based on user ID given
        public string updateUser(User updateUser, int? id)
        { 
            var vUser = db.Users;
            int count = 0;

            updateUser.UserId = id.Value;

            foreach (var u in vUser)
            {
                if (updateUser.UserId == u.UserId)
                {
                    u.Name = updateUser.Name;
                    u.Email = updateUser.Email;
                    count++;
                }
            }

            if (count == 0)
            {
                throw new Exception("NO USER IN THE SYSTEM!");
            }
            else
            {
                db.SaveChanges();
                return "User Name and Email Updated";
            }
        }
        // IMPLEMENTED ^

        public string updateUserPassword(string userEmail, string updatedPwd)
        {
            var vUser = db.Users;
            int count = 0;

            foreach (var u in vUser)
            {
                if ( u.Email == userEmail)
                {
                    u.Password = updatedPwd;
                    count++;
                }
            }

            if (count == 0)
            {
                throw new Exception("NO USER IN THE SYSTEM!");
            }
            else
            {
                db.SaveChanges();
                return "User Password Updated";
            }
        }
        // IMPLEMENTED ^
        #endregion

        #region DELETE
        public string deleteUser(User removeUser, int? id)
        {
            removeUser.UserId = id.Value;
            var vUser = from u in db.Users
                        where u.UserId == removeUser.UserId
                        select u;

            if (vUser.Count() == 0)
            {
                throw new Exception("NO USER IN THE SYSTEM!");
            }
            else
            {
                
                foreach (var us in vUser)
                {
                    if ((us.Email == removeUser.Email) &&
                        (us.Password == removeUser.Password) &&
                        (us.Name == removeUser.Name))
                    {
                        db.Users.Remove(us);

                    }
                    else
                    {
                        db.SaveChanges();
                        throw new Exception("USER DATA MIS-MATCH!!!");
                    }
                }
                db.SaveChanges();
                return "User removed from the system!";
            }
        }
        // IMPLEMENTED ^
        public string deleteUser(User removeUser, bool? confirmation, int? id)
        {
            removeUser.UserId = id.Value;
            var vUser = from u in db.Users
                        where u.UserId == removeUser.UserId
                        select u;
            if (confirmation == true)
            {
                if (vUser.Count() == 0)
                {
                    throw new Exception("NO USER IN THE SYSTEM!");
                }
                else
                {
                    foreach (var us in vUser)
                    {
                        if ((us.Email == removeUser.Email) &&
                            (us.Password == removeUser.Password) &&
                            (us.Name == removeUser.Name))
                        {
                            db.Users.Remove(us);

                        }
                        else
                        {
                            db.SaveChanges();
                            throw new Exception("USER DATA MIS-MATCH!!!!");
                        }
                    }
                    db.SaveChanges();
                    return "User removed from the system!";
                }
            }
            else
            {
                throw new Exception("USER DELETION CONFIRMATION FAILED!");
            }
        }
        // IMPLEMENTED ^
        #endregion

    }
}
