﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

#nullable disable

namespace EventIt.Models.EF
{
    public partial class Plan
    {
        [JsonIgnore]
        public int PlanId { get; set; }
        public int? UserId { get; set; }
        public DateTime? PlanDateStart { get; set; }
        public DateTime? PlanDateEnd { get; set; }
        public string Details { get; set; }
        
        [JsonIgnore]
        public virtual User User { get; set; }


        //#region CREATE
        //public string createPlan(Plan newPlan)
        //{
        //    return "test";
        //}
        //#endregion

        //#region READ
        //public DbSet<Plan> getPlanListAll()
        //{

        //}

        //public DbSet<Plan> getPlanList(int? id)
        //{

        //}

        //#endregion

        //#region UPDATE
        //public string updatePlan(Plan updatePlan, int? id)
        //{

        //}

        //public string updatePlanStartTime(DateTime newStartTime, int? id)
        //{

        //}

        //public string updatePlanEndTime(DateTime newEndTime, int? id)
        //{

        //}

        //#endregion

        //#region DELETE
        //public string deletePlan(Plan removePlan, int? id)
        //{

        //}

        //public string deletePlan(Plan removePlan, bool? confirmation, int? id)
        //{

        //}

        //#endregion

    }
}
