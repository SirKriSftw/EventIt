﻿using EventIt.Models.EF;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace EventIt.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlanController : ControllerBase
    {
        #region Logger Setup
        private readonly ILogger<PlanController> _logger;

        public PlanController(ILogger<PlanController> logger)
        {
            _logger = logger;
        }
        #endregion

        static Plan _plan = new Plan();

        //#region POST
        //[HttpPost]
        //[Route("createPlan")]
        //public IActionResult createPlan(Plan newPlan)
        //{
        //    try
        //    {
        //        return Created("", _plan.createPlan(newPlan));
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }

        //}
        //#endregion

        //#region GET
        //[HttpGet]
        //[Route("getPlan/All")]
        //public IActionResult getPlanListAll()
        //{
        //    try
        //    {
        //        return Ok();
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpGet]
        //[Route("getPlan/{id:int}")]
        //public IActionResult getPlanList(int? id)
        //{
        //    try
        //    {
        //        return Ok();
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }
        //}

        //#endregion

        //#region PUT
        //[HttpPut]
        //[Route("updatePlan")]
        //public IActionResult updatePlan(Plan updatePlan, int? id)
        //{
        //    try
        //    {
        //        return Accepted();
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpPut]
        //[Route("updatePlanStartTime")]
        //public IActionResult updatePlanStartTime(DateTime newStartTime, int? id)
        //{
        //    try
        //    {
        //        return Accepted();
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpPut]
        //[Route("updatePlanEndTime")]
        //public IActionResult updatePlanEndTime(DateTime newStartTime, int? id)
        //{
        //    try
        //    {
        //        return Accepted();
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }
        //}

        //#endregion


        //#region DELETE
        //[HttpDelete]
        //[Route("deletePlan")]
        //public IActionResult deletePlan(Plan removePlan, int? id)
        //{
        //    try
        //    {
        //        return Accepted();
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpDelete]
        //[Route("deletePlan2")]
        //public IActionResult deletePlan(Plan removePlan, bool? confirmation, int? id)
        //{
        //    try
        //    {
        //        return Accepted();
        //    }
        //    catch (System.Exception ex)
        //    {
        //        _logger.LogError(ex, ex.Message);
        //        return BadRequest(ex.Message);
        //    }
        //}
        //#endregion


    }
}
